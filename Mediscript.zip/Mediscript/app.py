from flask import Flask, request, render_template, send_file, redirect, url_for, session, send_from_directory, jsonify, flash
import io
import os
import requests
import base64
import json
import re
import logging
import openai
from dotenv import load_dotenv
from flask_session import Session
import time
import asyncio
import aiohttp
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import time
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Load environment variables
load_dotenv()

# Initialize Flask App
app = Flask(__name__)
logging.basicConfig(level=logging.DEBUG)

# Securely Load API Keys
GOOGLE_API_KEY = "AIzaSyDzGSBIG3dX6oyKVgsUmAzH0s597EWPAQg"
gemini_api_key = "AIzaSyAzDpBDBIzUaLiIAnKZkTLEdZarIM3t7-Y"

chrome_driver_path = r"C:\Users\hites\Downloads\chromedriver-win64\chromedriver-win64\chromedriver.exe"

options = Options()
options.add_argument("--headless")
options.add_argument("--disable-gpu")
options.add_argument("--window-size=1920x1080")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")

# Check for API Keys
if not gemini_api_key or not GOOGLE_API_KEY:
    logging.error("⚠️ Missing API Keys! Ensure they are set correctly.")
    exit(1)  # Stop execution if keys are missing

# Configure Secure Flask Session
app.config['SESSION_TYPE'] = 'filesystem'  # Use Redis or DB for production
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True  # Prevent tampering
app.config['SECRET_KEY'] = os.getenv("SECRET_KEY", "supersecretkey")
Session(app)

# Function to scrape medicine prices
def search_medicine_prices(medicine_name):
    driver = webdriver.Chrome(service=Service(os.getenv("CHROME_DRIVER_PATH")), options=options)
    results = []
    
    platforms = {
        "Truemeds": {
            "url": f"https://www.truemeds.in/search/{medicine_name}?search_type=COMPOSITION_SEARCH",
            "name_class": "sc-8b27b179-11",
            "price_class": "sc-8b27b179-17"
        },
        "PharmEasy": {
            "url": f"https://pharmeasy.in/search/all?name={medicine_name}",
            "name_class": "ProductCard_nameLogoContainer__lfDsP",
            "price_class": "ProductCard_gcdDiscountContainer__CCi51"
        },
        "Tata 1mg": {
            "url": f"https://www.1mg.com/search/all?name={medicine_name}",
            "name_class": "style__pro-title___3zxNC",
            "price_class": "style__price-tag___B2csA"
        }
    }

    for platform, config in platforms.items():
        try:
            driver.get(config['url'])
            time.sleep(3)
            
            names = driver.find_elements(By.CLASS_NAME, config['name_class'])
            prices = driver.find_elements(By.CLASS_NAME, config['price_class'])
            
            for name, price in zip(names, prices):
                results.append({
                    "pharmacy": platform,
                    "name": name.text.strip(),
                    "price": price.text.strip()
                });
                
        except Exception as e:
            app.logger.error(f"Failed {platform} scrape: {str(e)}")
    
    driver.quit()
    return results

# Route for the medicine search page
@app.route("/medicine", methods=["GET", "POST"])
def medicine_search():
    if request.method == "POST":
        medicine_name = request.form.get("medicine_name")
        if not medicine_name:
            return redirect(url_for("medicine_search"))
        results = search_medicine_prices(medicine_name)
        return render_template("medicine_search.html", results=results, medicine_name=medicine_name)
    return render_template("medicine_search.html")

# API route for fetching medicine prices
@app.route("/medicine-search", methods=["GET"])
def medicine_search_api():
    medicine_name = request.args.get("name")
    if not medicine_name:
        return jsonify({"error": "Medicine name is required"}), 400

    results = search_medicine_prices(medicine_name)
    return jsonify(results)

# ✅ Function to Extract Text from Image (Google Vision API)
def extract_text_from_image(image_file):
    base64_image = base64.b64encode(image_file.read()).decode('utf-8')
    payload = {
        "requests": [
            {
                "image": {"content": base64_image},
                "features": [{"type": "TEXT_DETECTION"}]
            }
        ]
    }
    url = f'https://vision.googleapis.com/v1/images:annotate?key={GOOGLE_API_KEY}'
    
    try:
        response = requests.post(url, headers={'Content-Type': 'application/json'}, data=json.dumps(payload), timeout=10)
        response.raise_for_status()
        response_json = response.json()
        text_annotations = response_json.get('responses', [])[0].get('textAnnotations', [])
        return text_annotations[0].get('description', '') if text_annotations else 'No text found in the image.'
    except requests.exceptions.RequestException as e:
        logging.error(f"Google Vision API Error: {e}")
        return 'Error processing image. Please try again.'

# ✅ Function to Format Chatbot Response
import re

def format_response(response_text, max_words=100):
    """
    Extracts medication names and usage instructions from the AI-generated response.
    Ensures proper formatting and limits output to 150 words, finishing the last sentence properly.
    """

    if not response_text or len(response_text.strip()) == 0:
        return "I'm sorry, but I couldn't generate a response."

    # Remove bold formatting (*)
    response_text = response_text.replace("*", "").strip()

    # Define keywords for detecting medication-related sections
    prescription_keywords = [
        "prescribed medications", "medication", "medications", "drugs",
        "treatment", "recommended medicines", "prescription"
    ]
    stop_keywords = [
        "diagnosis", "symptom", "treatment plan", "lifestyle", 
        "doctor", "when to see", "home care", "prevention"
    ]

    prescription_section = []
    extracting = False  # Flag to track if we are inside the prescription section

    # Split response into lines for processing
    lines = response_text.split('\n')

    for line in lines:
        line_lower = line.lower().strip()

        # Start extracting if any prescription-related keyword is found
        if any(keyword in line_lower for keyword in prescription_keywords):
            extracting = True
            continue  # Skip the section title itself

        # Stop extracting when encountering non-prescription sections
        if extracting and any(keyword in line_lower for keyword in stop_keywords):
            break

        # Extract lines containing medications, even if there's no explicit "Medication: Instruction" format
        if extracting and (":" in line or "-" in line):
            clean_line = line.lstrip("- ").strip()
            if ":" in clean_line:  # Standard format (Medication: Instruction)
                medication_name, instruction = map(str.strip, clean_line.split(":", 1))
                prescription_section.append(f"{medication_name}:\n{instruction}\n")
            else:  # If no colon, assume it's a medication name
                prescription_section.append(f"{clean_line}\n")

    # If no medications were found, attempt a fallback: detect common medication names in text
    if not prescription_section:
        potential_meds = re.findall(r'([A-Z][a-z]+(?: [A-Z][a-z]+)?)\s\d{1,3}mg', response_text)
        if potential_meds:
            prescription_section = [med + "\n" for med in set(potential_meds)]

    # Construct final formatted response
    response_text = "".join(prescription_section).strip()

    # Restrict output to 150 words while ensuring the last sentence completes
    words = response_text.split()
    if len(words) > max_words:
        truncated_text = " ".join(words[:max_words])

        # Ensure the response does not cut off mid-sentence
        last_sentence_end = max(truncated_text.rfind("."), truncated_text.rfind("!"), truncated_text.rfind("?"))
        if last_sentence_end != -1:
            response_text = truncated_text[: last_sentence_end + 1]
        else:
            response_text = truncated_text + "..."

    return response_text if response_text else "No prescription details found in the response."

def medical_chatbot(prompt):
    """
    A medical chatbot that uses the Gemini API.
    """
    greetings = {
        "hi": "Hello! How can I assist you with your medical concerns today?",
        "hello": "Hi there! What medical question can I help you with?",
        "hey": "Hey! How can I support you with your health-related queries?"
    }

    if prompt.lower() in greetings:
        return greetings[prompt.lower()]

    try:
        response = requests.post(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.0-pro:generateContent?key=" + gemini_api_key,
            headers={"Content-Type": "application/json"},
            json={
                "contents": [
                    {
                        "parts": [
                            {"text": f"You are a helpful medical assistant. {prompt}"}
                        ]
                    }
                ]
            }
        )
        response.raise_for_status()
        data = response.json()
        if 'candidates' in data and data['candidates'] and 'content' in data['candidates'][0] and 'parts' in data['candidates'][0]['content'] and data['candidates'][0]['content']['parts']:
            raw_response = data['candidates'][0]['content']['parts'][0]['text'].strip()
            return format_response(raw_response)
        else:
            return "Sorry, I couldn't generate a response."

    except requests.exceptions.RequestException as e:
        return f"An error occurred during the request: {e}"
    except (KeyError, IndexError, TypeError) as e:
        return f"An error occurred processing the response: {e}. Raw response: {response.text if 'response' in locals() else 'No response'}"
    except Exception as e:
        return f"An unexpected error occurred: {e}"

@app.route("/chat", methods=["POST"])
def chat():
    """
    Handles chat requests.
    """
    user_message = request.json.get("message")

    if not user_message:
        return jsonify({"response": "Invalid request. No message provided."}), 400

    reply = medical_chatbot(user_message)
    return jsonify({"response": reply})

# ✅ Flask Routes
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files.get("image")
        if file:
            try:
                text = extract_text_from_image(file)
                return render_template("index.html", text=text)
            except Exception as e:
                logging.error(f"Image processing error: {str(e)}")
                return render_template("index.html", text=f"Error: {str(e)}")
    return render_template("index.html")

# Other Routes
@app.route('/features')
def features():
    return render_template('features.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/login.html')
def login():
    return render_template('login.html')

@app.route('/signup.html')
def signup():
    return render_template('signup.html')

@app.route('/forgot-password.html')
def forgot_password():
    return render_template('forgot-password.html')

@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if request.method == 'POST':
        session['profile'] = {
            'name': request.form.get('name'),
            'email': request.form.get('email'),
            'phone': request.form.get('phone')
        }
        return redirect(url_for('profile'))
    return render_template('profile.html', profile=session.get('profile', {
        'name': 'Gottapu Hitesh',
        'email': 'hiteshgottapu309@gmail.com',
        'phone': '+91 8143506309'
    }))

@app.route('/download')
def download_file():
    text = request.args.get('text', '')
    text_file = io.BytesIO(text.encode('utf-8'))
    return send_file(text_file, as_attachment=True, download_name='extracted_text.txt', mimetype='text/plain')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/send_message', methods=['POST'])
def send_message():
    # Get form data
    name = request.form.get('name')
    message = request.form.get('message')

    # Email configuration
    sender_email = "hiteshgottapu@gmail.com"  # Replace with your email
    receiver_email = "gottapuhitesh@gmail.com"  # Fixed recipient email
    password = "your_email_password"  # Replace with your email password

    # Create the email
    subject = f"New Message from {name}"
    body = f"""
    Name: {name}
    Message: {message}
    """

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    # Send the email
    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, msg.as_string())
        return jsonify({"success": True, "message": "Message sent successfully!"})
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({"success": False, "message": "Failed to send message."})

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'), 'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/developers')
def developers():
    return render_template('developers.html')

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
